﻿namespace DeveloperTeam
{
    internal enum Level
    {
        Junior = 0,
        Middle = 1,
        Senior = 2,
    }
}
