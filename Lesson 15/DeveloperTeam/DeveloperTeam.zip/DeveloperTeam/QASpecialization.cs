﻿namespace DeveloperTeam
{
    internal enum QASpecialization
    {
        Manual = 0,
        Auto = 1,
    }
}
