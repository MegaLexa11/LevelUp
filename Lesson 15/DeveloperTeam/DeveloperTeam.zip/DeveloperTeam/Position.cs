﻿namespace DeveloperTeam
{
    internal enum Position
    {
        Developer = 0, 
        QAEngineer = 1,
        Analytic = 2,
        TeamLead = 3,
    }
}
