﻿namespace DeveloperTeam
{
    internal enum DeveloperSpecialization
    {
        Backend = 0,
        Web = 1,
        IOS = 2,
        Android = 3,
    }
}
