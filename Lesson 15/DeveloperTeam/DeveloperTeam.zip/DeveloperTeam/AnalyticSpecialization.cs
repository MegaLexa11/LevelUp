﻿namespace DeveloperTeam
{
    internal enum AnalyticSpecialization
    {
        SA = 0,
        BA = 1,
    }
}
